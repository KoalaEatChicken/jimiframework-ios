//
//  JIMIFile.h
//  JIMI
//
//  Created by ijm_mac on 2017/12/9.
//  Copyright © 2017年 JIMI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JIMIFile : NSObject

+ (JIMIFile *)JIMIShare;

- (void)gameInitSuccess:(void(^)(void))success andFailure:(void(^)(void))fail;

- (void)gameLoginSuccess:(void(^)(NSDictionary *dict))success andFailure:(void(^)(void))fail;

- (void)gameIAPWithBillno:(NSString *)billno flag:(NSString *)flag amount:(NSString *)amount serverid:(NSString *)serverid rolename:(NSString *)rolename rolelevel:(NSString *)rolelevel subject:(NSString *)subject extrainfo:(NSString *)extrainfo;

- (void)gameLoginoutSuccess:(void(^)(void))success andFailure:(void(^)(void))fail;

- (void)gameWillEnterForeground;

@end
