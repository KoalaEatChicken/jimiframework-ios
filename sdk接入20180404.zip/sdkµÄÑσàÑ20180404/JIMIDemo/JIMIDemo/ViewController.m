//
//  ViewController.m
//  JIMIDemo
//
//  Created by ijm_mac on 2017/12/9.
//  Copyright © 2017年 JIMI. All rights reserved.
//

#import "ViewController.h"
#import <JIMI/JIMIFile.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%f",[UIScreen mainScreen].bounds.size.width);
    self.view.backgroundColor = [UIColor yellowColor];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(switchuser:) name:@"JavascriptSwitchUser" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateData:) name:@"kaolaZF" object:nil];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)initaction:(id)sender {
    [[JIMIFile JIMIShare] gameInitSuccess:^() {
        NSLog(@"gameInitSuccess:返回是否测试提审 1测试");
    } andFailure:^{
        
    }];
}
- (IBAction)loginaction:(id)sender {
    [[JIMIFile JIMIShare] gameLoginSuccess:^(NSDictionary *dict) {
        NSLog(@"登录成功:%@",dict);
    } andFailure:^{
        
    }];
}
- (IBAction)payaction:(id)sender {
    
    [[JIMIFile JIMIShare] gameIAPWithBillno:@"111" flag:@"com.game.flag.6" amount:@"6" serverid:@"100" rolename:@"test" rolelevel:@"200" subject:@"test" extrainfo:@"test"];
}
- (IBAction)loginoutaction:(id)sender {
    [[JIMIFile JIMIShare] gameLoginoutSuccess:^{
        NSLog(@"登出成功，需要重新初始化");
    } andFailure:^{
        
    }];
}
- (void)switchuser:(NSNotification *)sender
{
    //此处做点击浮点按钮里“退出”按钮之后的游戏逻辑处理（例如点击后，返回游戏登录主界面）
    NSLog(@"这个是点击浮点里退出按钮的回调");
}

- (void)updateData:(NSNotification *)sender
{
    //此处是sdk充值回调
    NSLog(@"这个是调起sdk充值后的回调");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
