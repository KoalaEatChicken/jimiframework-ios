//
//  AppDelegate.h
//  JIMIDemo
//
//  Created by ijm_mac on 2017/12/9.
//  Copyright © 2017年 JIMI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

